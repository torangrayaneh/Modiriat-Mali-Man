package com.example.modiriatmaliman

import android.app.*
import android.os.Bundle
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

class DB(context: android.content.Context) : SQLiteOpenHelper(context, "finance.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE entries(id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT, title TEXT, amount INTEGER, day TEXT, note TEXT)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun add(kind:String,title:String,amount:Long,day:String,note:String) {
        writableDatabase.execSQL("INSERT INTO entries(kind,title,amount,day,note) VALUES(?,?,?,?,?)", arrayOf(kind,title,amount,day,note))
    }
    fun total(kind:String, month:String?=null):Long {
        val q = if(month==null) "SELECT COALESCE(SUM(amount),0) FROM entries WHERE kind=?" else "SELECT COALESCE(SUM(amount),0) FROM entries WHERE kind=? AND substr(day,1,7)=?"
        val c = if(month==null) readableDatabase.rawQuery(q, arrayOf(kind)) else readableDatabase.rawQuery(q, arrayOf(kind,month))
        c.moveToFirst(); val v=c.getLong(0); c.close(); return v
    }
    fun suggestions(prefix:String):List<String> {
        val c=readableDatabase.rawQuery("SELECT title, MAX(day) d FROM entries WHERE kind='expense' AND title LIKE ? GROUP BY title ORDER BY d DESC LIMIT 8", arrayOf("%$prefix%"))
        val a=mutableListOf<String>(); while(c.moveToNext()) a.add(c.getString(0)); c.close(); return a
    }
    fun lastAmount(title:String):Long? {
        val c=readableDatabase.rawQuery("SELECT amount FROM entries WHERE kind='expense' AND title=? ORDER BY day DESC,id DESC LIMIT 1", arrayOf(title))
        val v=if(c.moveToFirst()) c.getLong(0) else null; c.close(); return v
    }
    fun recent():List<String> {
        val c=readableDatabase.rawQuery("SELECT kind,title,amount,day FROM entries ORDER BY day DESC,id DESC LIMIT 20", null)
        val a=mutableListOf<String>()
        while(c.moveToNext()) a.add("${c.getString(3)}  •  ${c.getString(1)}  •  ${fmt(c.getLong(2))} تومان  •  ${if(c.getString(0)=="income") "واریزی" else "هزینه"}")
        c.close(); return a
    }
    companion object {
        fun fmt(n:Long)=NumberFormat.getInstance(Locale("fa","IR")).format(n)
    }
}

class MainActivity : Activity() {
    private lateinit var db:DB
    private lateinit var root:LinearLayout
    private val green=0xFF16865B.toInt()
    private val ink=0xFF17231E.toInt()
    private val muted=0xFF65736C.toInt()
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    override fun onCreate(savedInstanceState:Bundle?) {
        super.onCreate(savedInstanceState)
        db=DB(this)
        window.statusBarColor=0xFFF5F7F6.toInt()
        window.navigationBarColor=0xFFF5F7F6.toInt()
        window.decorView.systemUiVisibility=View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        showHome()
    }
    private fun page():LinearLayout {
        root=LinearLayout(this); root.orientation=LinearLayout.VERTICAL; root.layoutDirection=View.LAYOUT_DIRECTION_RTL
        root.setPadding(dp(18),dp(18),dp(18),dp(12)); root.setBackgroundColor(0xFFF5F7F6.toInt())
        val scroll=ScrollView(this); scroll.addView(root)
        setContentView(scroll); return root
    }
    private fun text(s:String,size:Float=16f,bold:Boolean=false,color:Int=ink):TextView {
        return TextView(this).apply { text=s; textSize=size; setTextColor(color); gravity=Gravity.RIGHT; if(bold)setTypeface(null,Typeface.BOLD); setPadding(0,dp(5),0,dp(5)) }
    }
    private fun add(v:View, h:Int=-2) { root.addView(v,LinearLayout.LayoutParams(-1,h).apply { bottomMargin=dp(8) }) }
    private fun button(s:String, action:()->Unit):Button = Button(this).apply {
        text=s; isAllCaps=false; setTextColor(0xFFFFFFFF.toInt()); setBackgroundTintList(android.content.res.ColorStateList.valueOf(green))
        setOnClickListener { action() }
    }
    private fun field(hint:String):EditText=EditText(this).apply {
        this.hint=hint; textSize=16f; gravity=Gravity.RIGHT; setSingleLine(true)
        setPadding(dp(12),dp(7),dp(12),dp(7)); setBackgroundColor(0xFFFFFFFF.toInt())
    }
    private fun currentMonth()=SimpleDateFormat("yyyy-MM",Locale.US).format(Date())
    private fun today()=SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date())
    private fun showHome() {
        page()
        add(text("مدیریت مالی من",26f,true,green))
        add(text("خلاصه وضعیت مالی • ${today()}",13f,false,muted))
        val m=currentMonth()
        val inc=db.total("income",m); val exp=db.total("expense",m); val bal=db.total("income")-db.total("expense")
        add(card("واریزی‌های این ماه",inc,0xFFE5F4EC.toInt()))
        add(card("هزینه‌های این ماه",exp,0xFFFBE9E7.toInt()))
        add(card("مانده کل تا امروز",bal,0xFFE8EEF9.toInt()))
        add(button("＋ ثبت واریزی") { showEntry("income") })
        add(button("− ثبت هزینه") { showEntry("expense") })
        add(button("گزارش ماهانه") { showReport() })
        add(text("آخرین تراکنش‌ها",19f,true))
        val items=db.recent()
        if(items.isEmpty()) add(text("هنوز تراکنشی ثبت نشده است.",14f,false,muted))
        else items.forEach { add(text(it,14f,false)) }
        add(text("یادآوری: تاریخ‌ها فعلاً به قالب میلادی ذخیره می‌شوند. پشتیبان‌گیری از داده‌ها در نسخه بعدی قابل افزودن است.",12f,false,muted))
    }
    private fun card(label:String,value:Long,bg:Int):View {
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(14),dp(10),dp(14),dp(10)); setBackgroundColor(bg) }
        box.addView(text(label,14f,false,muted)); box.addView(text("${DB.fmt(value)} تومان",23f,true))
        return box
    }
    private fun showEntry(kind:String) {
        page()
        val income=kind=="income"
        add(text(if(income)"ثبت واریزی" else "ثبت هزینه",24f,true,green))
        val title=field(if(income)"عنوان واریزی" else "عنوان هزینه (مثلاً کرایه تاکسی)")
        val amount=field("مبلغ به تومان")
        val day=field("تاریخ میلادی YYYY-MM-DD (مثلاً ${today()})").apply { setText(today()) }
        val note=field("توضیحات (اختیاری)")
        add(text("عنوان",13f,false,muted)); add(title)
        val suggest=TextView(this).apply { textSize=13f; setTextColor(green); gravity=Gravity.RIGHT }
        if(!income) {
            add(suggest)
            title.addTextChangedListener(object:android.text.TextWatcher {
                override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){}
                override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int) {
                    val matches=db.suggestions(s.toString())
                    suggest.text=if(matches.isEmpty()) "" else "پیشنهادها: "+matches.joinToString("، ")
                    val last=db.lastAmount(s.toString())
                    if(last!=null && s.toString().isNotBlank() && amount.text.isNullOrBlank()) amount.setText(last.toString())
                }
                override fun afterTextChanged(s:android.text.Editable?){}
            })
        }
        add(text("مبلغ",13f,false,muted)); add(amount)
        add(text("تاریخ",13f,false,muted)); add(day)
        add(text("توضیحات",13f,false,muted)); add(note)
        add(button("ذخیره") {
            val t=title.text.toString().trim()
            val a=amount.text.toString().replace(",","").trim().toLongOrNull()
            val d=day.text.toString().trim()
            if(t.isEmpty() || a==null || a<=0 || !d.matches(Regex("\\d{4}-\\d{2}-\\d{2}"))) {
                Toast.makeText(this,"عنوان، مبلغ معتبر و تاریخ YYYY-MM-DD را وارد کنید",Toast.LENGTH_LONG).show()
            } else {
                db.add(kind,t,a,d,note.text.toString())
                Toast.makeText(this,"اطلاعات ذخیره شد",Toast.LENGTH_SHORT).show()
                showHome()
            }
        })
        add(button("بازگشت") { showHome() })
    }
    private fun showReport() {
        page()
        add(text("گزارش ماهانه",24f,true,green))
        val month=field("ماه میلادی YYYY-MM (مثلاً ${currentMonth()})").apply { setText(currentMonth()) }
        add(text("ماه موردنظر",14f,false,muted)); add(month)
        val result=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        add(result)
        fun update() {
            result.removeAllViews()
            val m=month.text.toString()
            if(!m.matches(Regex("\\d{4}-\\d{2}"))) { result.addView(text("ماه را به صورت YYYY-MM وارد کنید",14f)); return }
            val i=db.total("income",m); val e=db.total("expense",m)
            result.addView(text("مجموع واریزی: ${DB.fmt(i)} تومان",18f,true))
            result.addView(text("مجموع هزینه: ${DB.fmt(e)} تومان",18f,true))
            result.addView(text("مانده ماه: ${DB.fmt(i-e)} تومان",20f,true,green))
            result.addView(text("مانده تجمعی تا پایان ماه: ${DB.fmt(db.total("income")-db.total("expense"))} تومان",14f,false,muted))
        }
        add(button("نمایش گزارش") { update() }); update()
        add(button("بازگشت") { showHome() })
    }
}
